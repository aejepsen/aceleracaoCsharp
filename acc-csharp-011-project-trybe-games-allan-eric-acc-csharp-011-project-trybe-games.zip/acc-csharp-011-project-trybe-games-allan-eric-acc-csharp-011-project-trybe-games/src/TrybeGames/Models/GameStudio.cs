namespace TrybeGames;

public class GameStudio
{
    public int Id;
    
    public string Name = "";

    public DateTime CreatedAt;
}