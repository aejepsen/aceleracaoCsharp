namespace SchoolQueries;

public class ProjectGrade
{
    public int ProjectId { get; set; }
    public int StudentId { get; set; }
    public int[]? Grades { get; set; }
}
