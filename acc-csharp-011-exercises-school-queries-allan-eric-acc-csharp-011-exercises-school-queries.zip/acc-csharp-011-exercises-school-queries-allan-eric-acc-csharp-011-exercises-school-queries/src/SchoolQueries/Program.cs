﻿using System;
//  ok
namespace SchoolQueries;
class Program
{
    static void Main(string[] args)
    {
        var database = new SchoolDatabase();
    }
}
