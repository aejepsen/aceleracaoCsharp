﻿namespace delivery_server;
public class Item
{
// Uma variável Name, do tipo string
// Uma variável Price, do tipo double
// Uma variável TimeToPrepare, do tipo int

    public string? Name { get; set; }
    public double Price { get; set; }
    public int TimeToPrepare { get; set; }

    public Item(string name, double price, int timeToPrepare)
    {
        Name = name;
        Price = price;
        TimeToPrepare = timeToPrepare;
    }
}