﻿using System;
using System.Threading;
//  ok
namespace delivery_server;

public class Order
{
    public Item OrderItem { get; set; }
    public int Quantity { get; set; }
    public double OrderPrice { get; set; }
    public bool IsReady { get; set; }
    public bool IsSend { get; set; }

    public Order(Item orderItem, int quantity)
    {
        OrderItem = orderItem;
        Quantity = quantity;
        OrderPrice = orderItem.Price * quantity;
        IsReady = false;
        IsSend = false;

        Task.Run(() => Process());
    }

    public void Process()
    {       
        Task.Delay(OrderItem.TimeToPrepare * Quantity).Wait();
        IsReady = true;
    }
}
