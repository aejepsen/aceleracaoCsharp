﻿using System;
using System.Collections;
using System.Threading;
using System.Threading.Tasks;

namespace delivery_server;

public class ProcessOrders
{
    public ArrayList OrdersList;
    public int TimeToCheck;

    // public ProcessOrders()
    // {   
    //     throw new NotImplementedException();
    //     this.DeliveryReadyOrders(TimeSpan.FromSeconds(TimeToCheck));    
    // }

// Criar a classe ProcessOrder

// Cada item deve ter:

// Uma variável OrdersList, do tipo ArrayList
// Uma variável TimeToCheck, do tipo int
// Criar o construtor da classe ProcessOrder

// O construtor deve alterar a variável TimeToCheck para 1.

// Esse será o valor de espera para cada checagem

// O construtor deve iniciar um novo ArrayList().

// O construtor deve imprimir a string "SERVER:> Controlador de delivery iniciado!".

// Usaremos a biblioteca TimeSpan para executar uma tarefa a cada espaço de tempo.

public ProcessOrders()
{
    this.TimeToCheck = 1;
    this.OrdersList = new ArrayList();
    Console.WriteLine("SERVER:> Controlador de delivery iniciado!");
}

    public void AddOrder(Item item, int quantity)
    {
        Order order = new Order(new Item(item.Name, item.Price, item.TimeToPrepare), quantity);
        OrdersList.Add(order);

        Console.WriteLine($"SERVER:> {quantity} * {item.Name} adicionados");
        this.DeliveryReadyOrders(TimeSpan.FromSeconds(TimeToCheck));

    }
    async Task DeliveryReadyOrders(TimeSpan timeSpan)
    {
        var periodicTimer = new PeriodicTimer(timeSpan);
        while (await periodicTimer.WaitForNextTickAsync())
        {
            foreach ( Order order in OrdersList)
            {
                if (order.IsReady == true &&  order.IsSend == false)
                {
                    order.IsSend = true;
                    Console.WriteLine($"SERVER:> O pedido de {order.Quantity} {order.OrderItem.Name} no valor de {order.OrderPrice} Reais foi enviado!");
                }
                else
                {
                    Console.WriteLine("SERVER:> Nenhum pedido está pronto para enviar!");
                }

            }
            
        }
    }

}
