using Xunit;
using FluentAssertions;
using delivery_server;
using System;

namespace delivery_server.Test;

public class TestReq1
{
    [Theory(DisplayName = "Deve construir um Item corretamente")]
    [InlineData("Hambúrguer", 15.0, 10)]
    [InlineData("Pizza", 25.0, 20)]
    [InlineData("Refrigerante", 5.0, 5)]

    public void TestCreateItem(string nameEntry, double priceEntry, int timeEntry)
    {
         // Arrange
        Item item;

        // Act
        item = new Item(nameEntry, priceEntry, timeEntry);

        // Assert
        item.Name.Should().Be(nameEntry);
        item.Price.Should().Be(priceEntry);
        item.TimeToPrepare.Should().Be(timeEntry);
    }
}