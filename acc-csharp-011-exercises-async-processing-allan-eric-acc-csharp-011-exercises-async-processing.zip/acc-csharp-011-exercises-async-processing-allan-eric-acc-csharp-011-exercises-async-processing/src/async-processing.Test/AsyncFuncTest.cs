using Xunit;
using FluentAssertions;
using System;
using async_processing;
using System.Threading.Tasks;
using System.Diagnostics;

namespace async_processing.Test;

[Collection("Sequential")]
public class AsyncFuncTest
{
    [Fact(DisplayName = "DoubleTheValueInGenericEntry deve ser assincrono e retornar a resposta correta após o tempo decorrido")]    
    public async Task TestThrowSomeAsyncException()
    {
        var asyncFunc = new AsyncFunc();
        var stopwatch = new Stopwatch();
        stopwatch.Start();
        await Assert.ThrowsAsync<Exception>(async () => await asyncFunc.ThrowSomeAsyncException());
        stopwatch.Stop();
        stopwatch.ElapsedMilliseconds.Should().BeGreaterOrEqualTo(5000);
    }
    

    [Theory(DisplayName = "DoubleTheValueInGenericEntry deve ser assincrono e retornar a resposta correta após o tempo decorrido")]
    [InlineData(1, 1000, 2)]
    [InlineData(2, 2000, 4)]
    [InlineData(3, 3000, 6)]
    [InlineData(4, 4000, 8)]
    [InlineData(5, 5000, 10)]
    public async Task TestDoubleTheValueInGenericEntry(int entry, int delay, int expectedValue)
    {
        var asyncFunc = new AsyncFunc();
        var stopwatch = new Stopwatch();
        stopwatch.Start();
        var result = await asyncFunc.DoubleTheValueInGenericEntry(entry, delay);
        stopwatch.Stop();
        result.Should().Be(expectedValue);

    }
 	
}