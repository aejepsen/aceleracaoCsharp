﻿using System;
using System.Threading.Tasks;

namespace async_processing;

public class AsyncFunc
{

    public async Task ThrowSomeAsyncException()
    {
        await Task.Delay(5000);
        throw new Exception("Exception");
    }

    public async Task<int> DoubleTheValueInGenericEntry(int entry, int delay)
    {
        await Task.Delay(delay);
        return entry * 2;
    }
         
}
